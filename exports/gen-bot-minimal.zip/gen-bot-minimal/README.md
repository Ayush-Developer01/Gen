# Gen Discord Bot - Minimal Package

## Run with Docker

1. Build: `docker build -t gen-bot .`
2. Run: `docker run -e DISCORD_TOKEN=YOUR_TOKEN -v gen-data:/app/data gen-bot`

## Run without Docker

1. Install Node.js 18 or newer.
2. Run `npm install`.
3. Set the `DISCORD_TOKEN` environment variable.
4. Run `npm start`.

Never share your Discord token publicly. Add it as an environment variable on Render or another host.
