# Gen Discord Bot - Minimal Package

Complete compiled Discord bot in a compact package.

## Run

1. Install Node.js 18 or newer.
2. Run `npm install`.
3. Set `DISCORD_TOKEN` as an environment variable.
4. Run `npm start`.

The included Dockerfile can be used on Render and other Docker hosts.

The bot creates its data folder automatically. Use a persistent disk/volume to keep stocks and settings after restarts.

Never share your Discord token publicly.
