# Gen Discord Bot - Minimal Package

This compact package contains the complete compiled bot.

## Render / Docker

Use Docker deployment with this folder and add an environment variable:

`DISCORD_TOKEN=your-new-discord-token`

The included Dockerfile starts the bot automatically.

## Run without Docker

1. Install Node.js 18 or newer.
2. Run `npm install`.
3. Set `DISCORD_TOKEN` as an environment variable.
4. Run `npm start`.

The bot creates its `data` folder automatically. Use a persistent disk/volume if you want stocks and settings to survive restarts.

Never share your Discord token publicly.
